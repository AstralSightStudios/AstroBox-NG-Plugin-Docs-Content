---
title: 源码与职责索引
description: 壁纸生成器相关类型、逻辑、页面、入口、安装流程、测试与国际化文件索引。
---

以下路径均相对 AstroBox-NG 项目根目录 `/Volumes/Lexar/项目/Code/AstroBox-NG`。

## 核心类型

| 文件 | 职责 |
| --- | --- |
| `web/src/types/wallpaper.ts` | 解析后模板、图层、控制项、编辑状态和资源表类型 |
| `web/src/types/community/repo.ts` | manifest 的 `ext.wallpaperGenerator.configUrl` 类型 |
| `web/src/types/watchface.ts` | 表盘数据与编辑流程相关类型 |

## 配置与资源

| 文件 | 职责 |
| --- | --- |
| `web/src/logic/wallpaperConfig.ts` | 配置获取、GitHub URL 归一化、继承、旧格式转换、完整运行时校验 |
| `web/src/logic/networkSettings.ts` | 当前官方源白名单、选择和变化状态 |
| `web/src/logic/githubCdn.ts` | GitHub DoH、前缀代理、AboxMirror、GitCode 镜像转换和响应解码 |
| `web/src/logic/officialDevice.ts` | 收集实时/缓存型号，通过 OfficialV2 设备表解析官方资源设备 ID |
| `src-tauri/modules/provider/src/community/officialv2.rs` | 加载 `devices_v2.json` 并提供型号到资源设备 ID 的后端映射 |

## 渲染与取景

| 文件 | 职责 |
| --- | --- |
| `web/src/logic/wallpaperRenderer.ts` | 图片加载、初始状态、离屏图层、换色、蒙版、模糊、合成和 PNG 输出 |
| `web/src/logic/wallpaperBlur.ts` | 不依赖 Canvas filter 的预乘 alpha 像素模糊 |
| `web/src/logic/wallpaperMask.ts` | Rec.709 亮度与原 alpha 蒙版转换 |
| `web/src/logic/wallpaperTransform.ts` | viewport、cover、旋转最小缩放、平移边界、锚点、居中适配状态 |
| `web/src/logic/wallpaperDevice.ts` | 目标设备与连接状态解析、资源设备 ID 精确匹配、旧代号/IoT 型号兼容和应用阻断原因 |

## 编辑器 UI

| 文件 | 职责 |
| --- | --- |
| `web/src/pages/device/wallpaperEdit.tsx` | 编辑器页面、数据查询、模板状态、资源加载、控件、导出和应用 |
| `web/src/pages/device/wallpaperEdit.module.css` | 编辑器布局和局部样式 |
| `web/src/components/wallpaper/WallpaperStage.tsx` | 统一预览、Pointer Events 拖动和双指缩放 |

## 安装关联与入口

| 文件 | 职责 |
| --- | --- |
| `web/src/logic/wallpaperMetadata.ts` | manifest URL 提取、本地安装关联读写和删除 |
| `web/src/logic/queue/taskList.ts` | 下载/安装任务上的 `wallpaperConfigUrl` 字段 |
| `web/src/logic/queue/downloadhelper.ts` | 普通与试用下载向安装任务传递配置 URL |
| `web/src/logic/queue/installhelper.ts` | 安装成功记录关联、重装和强制卸载清理关联 |
| `web/src/logic/deviceWidgetLayout.ts` | wallpaper 小组件类型、默认布局、旧布局迁移和尺寸规范化 |
| `web/src/pages/device/index.tsx` | 设备主页当前表盘查询、小组件渲染、添加菜单和路由跳转 |
| `web/src/components/device/deviceCard.tsx` | 设备卡片当前表盘壁纸入口 |
| `web/src/pages/device/watchfaces.tsx` | 表盘列表壁纸入口和卸载关联清理 |

## 路由与文案

| 文件 | 职责 |
| --- | --- |
| `web/src/router/router.config.ts` | `/device/watchface/wallpaper` 页面映射 |
| `web/src/router/router.navigation.ts` | 编辑器移动导航隐藏规则 |
| `web/src/i18n/zh_CN.json` | 中文入口标题、描述和不可用文案 |
| `web/src/i18n/en_US.json` | 英文入口标题、描述和不可用文案 |

编辑器内部大部分专用文案当前直接位于 `wallpaperEdit.tsx`，入口通用文案位于 i18n 文件。

## 表盘应用

| 文件 | 职责 |
| --- | --- |
| `web/src/logic/watchfaceEdit.ts` | 将生成 PNG 作为表盘照片写入、传输进度与设备编辑调用 |
| `web/src/pages/device/watchfaceEdit.tsx` | 通用表盘编辑页，可用于对照能力数据和应用模型 |

## 自动化测试

| 文件 | 核心断言 |
| --- | --- |
| `web/wallpaperConfig.test.ts` | 新旧配置、继承、路径、校验和镜像 |
| `web/wallpaperRenderer.test.ts` | 顺序、共享壁纸、离屏蒙版和效果语义 |
| `web/wallpaperBlur.test.ts` | 像素扩散、透明边缘颜色和均匀表面 |
| `web/wallpaperTransform.test.ts` | cover、旋转、平移和锚点 |
| `web/wallpaperDevice.test.ts` | 资源设备 ID、旧代号/IoT 型号兼容、目标设备连接状态、识别状态与应用限制 |
| `web/wallpaperMask.test.ts` | 蒙版亮度与 alpha |

## 变更时的同步关系

| 变更 | 需要同步检查 |
| --- | --- |
| 新增配置字段 | types、config parser、renderer/editor、示例、配置参考、校验测试 |
| 新增图层效果 | renderer、状态初始化/合并、UI 控件、预览导出应用一致性测试 |
| 修改设备键或识别链路 | officialDevice、OfficialV2 provider、wallpaperDevice、设备测试、多设备文档 |
| 修改 manifest 字段 | repo types、metadata、download/install、入口生命周期文档 |
| 修改小组件类型或尺寸 | deviceWidgetLayout、device page、迁移行为、入口验收 |
| 修改蒙版算法 | wallpaperMask、renderer 缓存、mask 测试、渲染与排障文档 |
| 修改官方源 | networkSettings、githubCdn、config URL 测试、资源网络文档 |
